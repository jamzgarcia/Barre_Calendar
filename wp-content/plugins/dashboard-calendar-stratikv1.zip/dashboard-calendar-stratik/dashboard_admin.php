<?php
$adminData = new adminQuestions();
// $data_type = $adminData->getTypeQuestions();
// $data_forms = $adminData->getListForms();
?>
<br>
<div class="card" style="width: 18rem;">
  <div class="card-header">
    Featured
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item">An item</li>
    <li class="list-group-item">A second item</li>
    <li class="list-group-item">A third item</li>
  </ul>
</div>

<?php

?>