$(document).ready(function () {
     console.log('Entry Select 2 Page js oki oki');
    
     $('.mi-selector').select2();
});